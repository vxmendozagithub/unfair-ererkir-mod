Blocks.plasmaBore.drillTime=Blocks.largePlasmaBore.drillTime=Blocks.cliffCrusher.drillTime=Blocks.impactDrill.drillTime=Blocks.eruptionDrill.drillTime=Blocks.ventCondenser.craftTime=1;
Blocks.siliconArcFurnace.craftTime=Blocks.electrolyzer.craftTime=Blocks.atmosphericConcentrator.craftTime=Blocks.surgeCrucible.craftTime=Blocks.carbideCrucible.craftTime=Blocks.cyanogenSynthesizer.craftTime=Blocks.phaseSythesizer.craftTime=1;
Blocks.slagcrucible.buildVisibility=Blocks.heatReactor.buildVisibility=BuildVisibility.shown
UnitTypes.elude.flying=true;
UnitTypes.cleroi.legCount=6;